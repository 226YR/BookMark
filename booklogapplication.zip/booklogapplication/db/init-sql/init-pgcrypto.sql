-- UUID型のデータを生成するための拡張機能を有効化
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
